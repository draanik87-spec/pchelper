#!/bin/bash
# Сборка index.html (в КОРНЕ — так его видят Vercel и GitHub Pages) из исходников-частей + проверка синтаксиса и данных.
# Порядок важен: part10 (путеводитель) после part9, до part6 (init вызывает рендеры).
set -e
cd "$(dirname "$0")"
cat parts/part1_head.html \
    parts/part1b_imgs.html \
    parts/part1b2_imgs.html \
    parts/part1c_fonts.html \
    parts/part2_body.html \
    parts/part3_data.html \
    parts/part3b_data2.html \
    parts/part3c_gpus2.html \
    parts/part4_logic.html \
    parts/part5_logic2.html \
    parts/part7_ac.html \
    parts/part8_chart.html \
    parts/part9_mybuild.html \
    parts/part10_sidenav.html \
    parts/part6_guide_init.html \
    parts/part12_close.html > index.html
node check.js
