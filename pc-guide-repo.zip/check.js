#!/usr/bin/env node
/* Проверка собранного index.html (корень репозитория): синтаксис скрипта + целостность данных */
const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');
const m = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(x=>x[1]);
if (!m.length) { console.error('SCRIPT NOT FOUND'); process.exit(1); }
m.forEach((s,i)=>{
 try { new Function(s.replace(/\b(document|window|requestAnimationFrame)\b/g, 'undefined')); }
 catch(e) { console.error('SYNTAX ERROR in script #'+i+':', e.message); process.exit(1); }
});
console.log('SYNTAX OK, scripts:', m.length, '| sizes:', m.map(s=>s.length).join('/'));
/* главный скрипт ищем по маркеру ЛОГИКА (three.min.js больше и маркера не содержит) */
const js = m.find(s=>s.indexOf("ЛОГИКА") > 0);
if (!js) { console.error("MAIN SCRIPT (ЛОГИКА) NOT FOUND"); process.exit(1); }

const dataPart = js.split('/* ============================================================ ЛОГИКА')[0];
const sandbox = {};
try {
  new Function('sandbox', dataPart + '; sandbox.GPUS=GPUS; sandbox.CPUS=CPUS; sandbox.MONITORS=MONITORS; sandbox.BUILDS=BUILDS; sandbox.GAMES=GAMES;')(sandbox);
} catch(e) { console.error('DATA EXEC ERROR:', e.message); process.exit(1); }
const {GPUS, CPUS, MONITORS, BUILDS, GAMES} = sandbox;
console.log('GPUS:', GPUS.length, '| CPUS:', CPUS.length, '| MONITORS:', MONITORS.length, '| BUILDS:', BUILDS.length, '| GAMES:', GAMES.length);
for (const [name, arr] of [['GPUS',GPUS],['CPUS',CPUS],['MONITORS',MONITORS]]){
  const ids = arr.map(x=>x.id);
  if (new Set(ids).size !== ids.length) console.error('DUP IDS in', name);
  arr.forEach(x => { if (!x.name || !x.price) console.error('MISSING name/price in', name, x.id); });
}
GPUS.forEach(g => GAMES.forEach(gm => { if (!Number.isFinite(g.fps[gm.id]) || g.fps[gm.id] <= 0) console.error('BAD FPS', g.id, gm.id); }));
CPUS.forEach(c => GAMES.forEach(gm => { if (!Number.isFinite(c.cap[gm.id]) || c.cap[gm.id] <= 0) console.error('BAD CAP', c.id, gm.id); }));
BUILDS.forEach(b => {
  if (!GPUS.some(g=>g.id===b.gpu)) console.error('BUILD', b.id, 'bad gpu', b.gpu);
  if (!CPUS.some(c=>c.id===b.cpu)) console.error('BUILD', b.id, 'bad cpu', b.cpu);
});
console.log('DATA CHECK DONE');
